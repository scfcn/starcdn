<?php

define('JWT_KEY' , 'iusangopuehr89ahohtp9suiogna3op59g8es16');