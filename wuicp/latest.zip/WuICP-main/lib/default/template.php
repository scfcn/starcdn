<?php
// 如果这个文件被直接访问，则退出
// if (!defined('ABSPATH')) {
//     exit('不允许直接访问');
// }