/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * The interface for a Blockly component that can be registered.
 */
export interface IRegistrable {
}
//# sourceMappingURL=i_registrable.d.ts.map