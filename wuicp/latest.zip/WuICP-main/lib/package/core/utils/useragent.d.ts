/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
export declare const raw: string;
export declare const JavaFx: boolean;
export declare const GECKO: boolean;
export declare const ANDROID: boolean;
export declare const IPAD: boolean;
export declare const IPHONE: boolean;
export declare const MAC: boolean;
export declare const MOBILE: boolean;
//# sourceMappingURL=useragent.d.ts.map