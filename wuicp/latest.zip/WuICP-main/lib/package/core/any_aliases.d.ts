/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
type any = any;
//# sourceMappingURL=any_aliases.d.ts.map