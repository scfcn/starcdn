<?php
// 插件配置信息
return [
    'name' => 'Dynamic Sidebar',
    'version' => '1.0',
    'description' => 'A plugin to dynamically add sidebar items.'
];